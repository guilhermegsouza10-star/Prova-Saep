<?php
// Proteção das páginas: exige login e controla expiração da sessão.
// Use: $raiz = "../"; (ou "" na raiz) antes de dar require deste arquivo.

date_default_timezone_set('America/Sao_Paulo');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($raiz)) {
    $raiz = "";
}

const TEMPO_SESSAO = 600; // 10 minutos de inatividade

if (empty($_SESSION['usuario_id'])) {
    header("Location: {$raiz}login.php?msg=" . urlencode("Faça login para continuar."));
    exit;
}

if (isset($_SESSION['ultimo_acesso']) && (time() - $_SESSION['ultimo_acesso']) > TEMPO_SESSAO) {
    session_unset();
    session_destroy();
    header("Location: {$raiz}login.php?msg=" . urlencode("Sessão expirada. Faça login novamente."));
    exit;
}

$_SESSION['ultimo_acesso'] = time();

require_once __DIR__ . '/conexao.php';
require_once __DIR__ . '/funcoes.php';
require_once __DIR__ . '/layout.php';
