<?php
// Cabeçalho e rodapé comuns (barra com nome do usuário, menu e botão Sair)

function cabecalho($titulo, $raiz = "")
{
    $nome = e($_SESSION['nome'] ?? '');
    echo <<<HTML
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{$titulo} - Clínica Veterinária</title>
    <link rel="stylesheet" href="{$raiz}assets/style.css">
</head>
<body>
<nav class="navbar">
    <a class="logo" href="{$raiz}index.php">🐾 Clínica Veterinária</a>
    <ul class="nav-links">
        <li><a href="{$raiz}tutor/listar.php">Tutores</a></li>
        <li><a href="{$raiz}pet/listar.php">Pets</a></li>
        <li><a href="{$raiz}agendamento/listar.php">Agendamentos</a></li>
    </ul>
    <div class="user-box">
        <span class="user-name">👤 {$nome}</span>
        <a href="{$raiz}logout.php" class="btn-logout">Sair</a>
    </div>
</nav>
<main class="container">
HTML;
}

function rodape()
{
    echo "\n</main>\n</body>\n</html>";
}

function mensagem()
{
    if (!empty($_GET['ok'])) {
        echo '<div class="alert ok">' . e($_GET['ok']) . '</div>';
    }
    if (!empty($_GET['erro'])) {
        echo '<div class="alert erro">' . e($_GET['erro']) . '</div>';
    }
}
