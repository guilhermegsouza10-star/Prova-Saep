<?php
$raiz = "../";
require __DIR__ . '/../auth.php';

$resultado = $conn->query(
    "SELECT p.*, t.nome AS tutor_nome
     FROM pets p INNER JOIN tutores t ON t.id = p.id_tutor
     ORDER BY p.nome"
);

cabecalho("Pets", $raiz);
?>
<div class="top">
    <h1>Pets</h1>
    <a class="btn" href="inserir.php">+ Novo Pet</a>
</div>

<?php mensagem(); ?>

<table>
    <thead>
        <tr><th>ID</th><th>Nome</th><th>Espécie</th><th>Raça</th><th>Idade</th><th>Tutor</th><th>Ações</th></tr>
    </thead>
    <tbody>
    <?php if ($resultado && $resultado->num_rows): ?>
        <?php while ($p = $resultado->fetch_assoc()): ?>
            <tr>
                <td><?= (int) $p['id'] ?></td>
                <td><?= e($p['nome']) ?></td>
                <td><?= e($p['especie']) ?></td>
                <td><?= e($p['raca']) ?></td>
                <td><?= e($p['idade']) ?></td>
                <td><?= e($p['tutor_nome']) ?></td>
                <td>
                    <a href="editar.php?id=<?= (int) $p['id'] ?>">Editar</a>
                    <a class="delete" href="apagar.php?id=<?= (int) $p['id'] ?>"
                       onclick="return confirm('Excluir este pet? Os agendamentos dele também serão excluídos.')">Excluir</a>
                </td>
            </tr>
        <?php endwhile; ?>
    <?php else: ?>
        <tr><td colspan="7">Nenhum pet cadastrado.</td></tr>
    <?php endif; ?>
    </tbody>
</table>
<?php rodape(); ?>
