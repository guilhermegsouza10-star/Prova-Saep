<?php
$raiz = "../";
require __DIR__ . '/../auth.php';

$erro = '';
$v = ['id_tutor' => '', 'nome' => '', 'especie' => '', 'raca' => '', 'idade' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $v['id_tutor'] = (int) ($_POST['id_tutor'] ?? 0);
    $v['nome']     = trim($_POST['nome'] ?? '');
    $v['especie']  = trim($_POST['especie'] ?? '');
    $v['raca']     = trim($_POST['raca'] ?? '');
    $v['idade']    = $_POST['idade'] ?? '';

    // Todo pet precisa estar associado a um tutor existente
    $chk = $conn->prepare("SELECT id FROM tutores WHERE id = ?");
    $chk->bind_param("i", $v['id_tutor']);
    $chk->execute();
    $tutorExiste = $chk->get_result()->num_rows > 0;

    if (!$tutorExiste) {
        $erro = "Selecione um tutor para o pet.";
    } elseif ($v['nome'] === '' || $v['especie'] === '') {
        $erro = "Informe nome e espécie.";
    } else {
        $idade = ($v['idade'] === '') ? null : max(0, (int) $v['idade']);
        $stmt = $conn->prepare("INSERT INTO pets (id_tutor, nome, especie, raca, idade) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("isssi", $v['id_tutor'], $v['nome'], $v['especie'], $v['raca'], $idade);
        $stmt->execute();
        header("Location: listar.php?ok=" . urlencode("Pet cadastrado com sucesso."));
        exit;
    }
}

$tutores = $conn->query("SELECT id, nome FROM tutores ORDER BY nome");
cabecalho("Novo Pet", $raiz);
?>
<div class="card estreito">
    <h1>Cadastrar Pet</h1>
    <?php if ($erro): ?><div class="alert erro"><?= e($erro) ?></div><?php endif; ?>
    <form method="post">
        <div class="input-group"><label>Tutor</label>
            <select name="id_tutor" required>
                <option value="">Selecione o tutor...</option>
                <?php while ($t = $tutores->fetch_assoc()): ?>
                    <option value="<?= (int) $t['id'] ?>" <?= $v['id_tutor'] == $t['id'] ? 'selected' : '' ?>><?= e($t['nome']) ?></option>
                <?php endwhile; ?>
            </select></div>
        <div class="input-group"><label>Nome do pet</label>
            <input name="nome" value="<?= e($v['nome']) ?>" required></div>
        <div class="input-group"><label>Espécie</label>
            <input name="especie" value="<?= e($v['especie']) ?>" placeholder="Cachorro, Gato..." required></div>
        <div class="input-group"><label>Raça</label>
            <input name="raca" value="<?= e($v['raca']) ?>"></div>
        <div class="input-group"><label>Idade (anos)</label>
            <input type="number" min="0" name="idade" value="<?= e($v['idade']) ?>"></div>
        <div class="btn-group">
            <a class="btn btn-cancel" href="listar.php">Cancelar</a>
            <button class="btn" type="submit">Salvar</button>
        </div>
    </form>
</div>
<?php rodape(); ?>
