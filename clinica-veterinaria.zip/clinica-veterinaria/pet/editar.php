<?php
$raiz = "../";
require __DIR__ . '/../auth.php';

$id = (int) ($_GET['id'] ?? 0);
$stmt = $conn->prepare("SELECT * FROM pets WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$pet = $stmt->get_result()->fetch_assoc();

if (!$pet) {
    header("Location: listar.php?erro=" . urlencode("Pet não encontrado."));
    exit;
}

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pet['id_tutor'] = (int) ($_POST['id_tutor'] ?? 0);
    $pet['nome']     = trim($_POST['nome'] ?? '');
    $pet['especie']  = trim($_POST['especie'] ?? '');
    $pet['raca']     = trim($_POST['raca'] ?? '');
    $pet['idade']    = $_POST['idade'] ?? '';

    $chk = $conn->prepare("SELECT id FROM tutores WHERE id = ?");
    $chk->bind_param("i", $pet['id_tutor']);
    $chk->execute();

    if ($chk->get_result()->num_rows === 0) {
        $erro = "Selecione um tutor para o pet.";
    } elseif ($pet['nome'] === '' || $pet['especie'] === '') {
        $erro = "Informe nome e espécie.";
    } else {
        $idade = ($pet['idade'] === '' || $pet['idade'] === null) ? null : max(0, (int) $pet['idade']);
        $stmt = $conn->prepare("UPDATE pets SET id_tutor = ?, nome = ?, especie = ?, raca = ?, idade = ? WHERE id = ?");
        $stmt->bind_param("isssii", $pet['id_tutor'], $pet['nome'], $pet['especie'], $pet['raca'], $idade, $id);
        $stmt->execute();
        header("Location: listar.php?ok=" . urlencode("Pet atualizado com sucesso."));
        exit;
    }
}

$tutores = $conn->query("SELECT id, nome FROM tutores ORDER BY nome");
cabecalho("Editar Pet", $raiz);
?>
<div class="card estreito">
    <h1>Editar Pet</h1>
    <?php if ($erro): ?><div class="alert erro"><?= e($erro) ?></div><?php endif; ?>
    <form method="post">
        <div class="input-group"><label>Tutor</label>
            <select name="id_tutor" required>
                <?php while ($t = $tutores->fetch_assoc()): ?>
                    <option value="<?= (int) $t['id'] ?>" <?= $pet['id_tutor'] == $t['id'] ? 'selected' : '' ?>><?= e($t['nome']) ?></option>
                <?php endwhile; ?>
            </select></div>
        <div class="input-group"><label>Nome do pet</label>
            <input name="nome" value="<?= e($pet['nome']) ?>" required></div>
        <div class="input-group"><label>Espécie</label>
            <input name="especie" value="<?= e($pet['especie']) ?>" required></div>
        <div class="input-group"><label>Raça</label>
            <input name="raca" value="<?= e($pet['raca']) ?>"></div>
        <div class="input-group"><label>Idade (anos)</label>
            <input type="number" min="0" name="idade" value="<?= e($pet['idade']) ?>"></div>
        <div class="btn-group">
            <a class="btn btn-cancel" href="listar.php">Cancelar</a>
            <button class="btn" type="submit">Atualizar</button>
        </div>
    </form>
</div>
<?php rodape(); ?>
