<?php
$raiz = "";
require __DIR__ . '/auth.php';
cabecalho("Início", $raiz);
?>
<div class="welcome-card">
    <h1>Bem-vindo(a), <?= e($_SESSION['nome']) ?>!</h1>
    <p>Gerencie tutores, pets e agendamentos da clínica. Use o menu superior ou os atalhos abaixo.<br>
       Por segurança, a sessão expira após 10 minutos de inatividade.</p>
</div>

<div class="atalhos">
    <a class="atalho" href="tutor/listar.php"><span>👤</span>Tutores</a>
    <a class="atalho" href="pet/listar.php"><span>🐶</span>Pets</a>
    <a class="atalho" href="agendamento/listar.php"><span>📅</span>Agendamentos</a>
</div>
<?php rodape(); ?>
