<?php
// Funções auxiliares

function e($valor)
{
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}

// Mantém só os dígitos do CPF
function cpf_digitos($cpf)
{
    return preg_replace('/\D/', '', (string) $cpf);
}

// Formata como 000.000.000-00 (formato usado no hash do banco)
function cpf_formatar($cpf)
{
    $d = cpf_digitos($cpf);
    return substr($d, 0, 3) . '.' . substr($d, 3, 3) . '.' . substr($d, 6, 3) . '-' . substr($d, 9, 2);
}

function cpf_valido($cpf)
{
    return strlen(cpf_digitos($cpf)) === 11;
}

// CPF armazenado criptografado (SHA-256 do CPF formatado) - LGPD
function cpf_hash($cpf)
{
    return hash('sha256', cpf_formatar($cpf));
}

// Hash de senha (mesmo padrão dos usuários do banco)
function senha_hash($senha)
{
    return hash('sha256', $senha);
}

function formatar_data($data)
{
    return date('d/m/Y H:i', strtotime($data));
}
