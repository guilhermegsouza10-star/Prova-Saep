<?php
$raiz = "../";
require __DIR__ . '/../auth.php';

$id = (int) ($_GET['id'] ?? 0);
$stmt = $conn->prepare(
    "SELECT a.*, t.nome AS tutor_nome, p.nome AS pet_nome
     FROM agendamentos a
     INNER JOIN tutores t ON t.id = a.id_tutor
     INNER JOIN pets p ON p.id = a.id_pet
     WHERE a.id = ?"
);
$stmt->bind_param("i", $id);
$stmt->execute();
$ag = $stmt->get_result()->fetch_assoc();

if (!$ag) {
    header("Location: listar.php?erro=" . urlencode("Agendamento não encontrado."));
    exit;
}

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nova = str_replace('T', ' ', trim($_POST['data_agendamento'] ?? ''));
    $ts = strtotime($nova);

    if ($ts === false) {
        $erro = "Informe uma data e hora válidas.";
    } else {
        $nova = date('Y-m-d H:i:s', $ts);
        $stmt = $conn->prepare("UPDATE agendamentos SET data_agendamento = ? WHERE id = ?");
        $stmt->bind_param("si", $nova, $id);
        $stmt->execute();
        header("Location: listar.php?ok=" . urlencode("Data do agendamento atualizada."));
        exit;
    }
}

cabecalho("Alterar Agendamento", $raiz);
?>
<div class="card estreito">
    <h1>Alterar data do agendamento</h1>
    <?php if ($erro): ?><div class="alert erro"><?= e($erro) ?></div><?php endif; ?>
    <p class="small" style="margin-bottom:18px">
        Tutor: <strong><?= e($ag['tutor_nome']) ?></strong> •
        Pet: <strong><?= e($ag['pet_nome']) ?></strong><br>
        Motivo: <?= e($ag['motivo']) ?>
    </p>
    <form method="post">
        <div class="input-group"><label>Nova data e hora</label>
            <input type="datetime-local" name="data_agendamento"
                   value="<?= e(date('Y-m-d\TH:i', strtotime($ag['data_agendamento']))) ?>" required></div>
        <div class="btn-group">
            <a class="btn btn-cancel" href="listar.php">Cancelar</a>
            <button class="btn" type="submit">Atualizar</button>
        </div>
    </form>
</div>
<?php rodape(); ?>
