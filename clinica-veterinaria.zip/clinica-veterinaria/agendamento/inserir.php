<?php
$raiz = "../";
require __DIR__ . '/../auth.php';

$erro = '';
$v = ['id_tutor' => '', 'id_pet' => '', 'data' => '', 'motivo' => '', 'status' => 'Agendado'];
$statusPermitidos = ['Agendado', 'Confirmado', 'Cancelado', 'Concluído'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $v['id_tutor'] = (int) ($_POST['id_tutor'] ?? 0);
    $v['id_pet']   = (int) ($_POST['id_pet'] ?? 0);
    $v['data']     = trim($_POST['data_agendamento'] ?? '');
    $v['motivo']   = trim($_POST['motivo'] ?? '');
    $v['status']   = in_array($_POST['status'] ?? '', $statusPermitidos) ? $_POST['status'] : 'Agendado';

    // O pet precisa pertencer ao tutor escolhido
    $chk = $conn->prepare("SELECT id FROM pets WHERE id = ? AND id_tutor = ?");
    $chk->bind_param("ii", $v['id_pet'], $v['id_tutor']);
    $chk->execute();
    $ts = strtotime(str_replace('T', ' ', $v['data']));

    if ($chk->get_result()->num_rows === 0) {
        $erro = "Selecione um tutor e um pet que pertença a ele.";
    } elseif ($ts === false) {
        $erro = "Informe uma data e hora válidas.";
    } elseif ($v['motivo'] === '') {
        $erro = "Informe o motivo.";
    } else {
        $data = date('Y-m-d H:i:s', $ts);
        $stmt = $conn->prepare("INSERT INTO agendamentos (id_tutor, id_pet, data_agendamento, motivo, status) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("iisss", $v['id_tutor'], $v['id_pet'], $data, $v['motivo'], $v['status']);
        $stmt->execute();
        header("Location: listar.php?ok=" . urlencode("Agendamento cadastrado com sucesso."));
        exit;
    }
}

$tutores = $conn->query("SELECT id, nome FROM tutores ORDER BY nome");
$pets = $conn->query("SELECT id, id_tutor, nome FROM pets ORDER BY nome");
cabecalho("Novo Agendamento", $raiz);
?>
<div class="card estreito">
    <h1>Novo Agendamento</h1>
    <?php if ($erro): ?><div class="alert erro"><?= e($erro) ?></div><?php endif; ?>
    <form method="post">
        <div class="input-group"><label>Tutor</label>
            <select name="id_tutor" id="tutor" required>
                <option value="">Selecione o tutor...</option>
                <?php while ($t = $tutores->fetch_assoc()): ?>
                    <option value="<?= (int) $t['id'] ?>" <?= $v['id_tutor'] == $t['id'] ? 'selected' : '' ?>><?= e($t['nome']) ?></option>
                <?php endwhile; ?>
            </select></div>
        <div class="input-group"><label>Pet</label>
            <select name="id_pet" id="pet" required>
                <option value="">Selecione o pet...</option>
                <?php while ($p = $pets->fetch_assoc()): ?>
                    <option value="<?= (int) $p['id'] ?>" data-tutor="<?= (int) $p['id_tutor'] ?>"
                        <?= $v['id_pet'] == $p['id'] ? 'selected' : '' ?>><?= e($p['nome']) ?></option>
                <?php endwhile; ?>
            </select></div>
        <div class="input-group"><label>Data e hora</label>
            <input type="datetime-local" name="data_agendamento" value="<?= e($v['data']) ?>" required></div>
        <div class="input-group"><label>Motivo</label>
            <input name="motivo" value="<?= e($v['motivo']) ?>" maxlength="255" required></div>
        <div class="input-group"><label>Status</label>
            <select name="status">
                <?php foreach ($statusPermitidos as $s): ?>
                    <option <?= $v['status'] === $s ? 'selected' : '' ?>><?= e($s) ?></option>
                <?php endforeach; ?>
            </select></div>
        <div class="btn-group">
            <a class="btn btn-cancel" href="listar.php">Cancelar</a>
            <button class="btn" type="submit">Salvar</button>
        </div>
    </form>
</div>

<script>
// Mostra só os pets do tutor selecionado
const selTutor = document.getElementById('tutor');
const selPet = document.getElementById('pet');
function filtrarPets() {
    const t = selTutor.value;
    for (const o of selPet.options) {
        if (!o.value) continue;
        const mostra = o.dataset.tutor === t;
        o.hidden = !mostra;
        o.disabled = !mostra;
    }
    if (selPet.selectedOptions[0] && selPet.selectedOptions[0].disabled) selPet.value = '';
}
selTutor.addEventListener('change', filtrarPets);
filtrarPets();
</script>
<?php rodape(); ?>
