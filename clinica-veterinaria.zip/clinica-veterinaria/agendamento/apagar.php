<?php
$raiz = "../";
require __DIR__ . '/../auth.php';

$id = (int) ($_GET['id'] ?? 0);
$stmt = $conn->prepare("DELETE FROM agendamentos WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
header("Location: listar.php?ok=" . urlencode("Agendamento excluído."));
exit;
