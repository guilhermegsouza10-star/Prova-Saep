<?php
$raiz = "../";
require __DIR__ . '/../auth.php';

// Agendamentos ordenados por dia, com todos os dados do tutor e do pet
$resultado = $conn->query(
    "SELECT a.id, a.data_agendamento, a.motivo, a.status,
            t.nome AS tutor_nome, t.telefone, t.email,
            p.nome AS pet_nome, p.especie, p.raca, p.idade
     FROM agendamentos a
     INNER JOIN tutores t ON t.id = a.id_tutor
     INNER JOIN pets p ON p.id = a.id_pet
     ORDER BY a.data_agendamento ASC"
);

cabecalho("Agendamentos", $raiz);
?>
<div class="top">
    <h1>Agendamentos</h1>
    <a class="btn" href="inserir.php">+ Novo Agendamento</a>
</div>

<?php mensagem(); ?>

<table>
    <thead>
        <tr>
            <th>Data / Hora</th><th>Motivo</th><th>Status</th>
            <th>Tutor</th><th>Contato</th><th>Pet</th><th>Ações</th>
        </tr>
    </thead>
    <tbody>
    <?php if ($resultado && $resultado->num_rows): ?>
        <?php while ($a = $resultado->fetch_assoc()): ?>
            <tr>
                <td><?= e(formatar_data($a['data_agendamento'])) ?></td>
                <td><?= e($a['motivo']) ?></td>
                <td><?= e($a['status']) ?></td>
                <td><?= e($a['tutor_nome']) ?></td>
                <td><?= e($a['telefone']) ?><br><span class="small"><?= e($a['email']) ?></span></td>
                <td><?= e($a['pet_nome']) ?><br>
                    <span class="small"><?= e($a['especie']) ?> • <?= e($a['raca']) ?> • <?= e($a['idade']) ?> ano(s)</span></td>
                <td>
                    <a href="editar.php?id=<?= (int) $a['id'] ?>">Alterar data</a>
                    <a class="delete" href="apagar.php?id=<?= (int) $a['id'] ?>"
                       onclick="return confirm('Excluir este agendamento?')">Excluir</a>
                </td>
            </tr>
        <?php endwhile; ?>
    <?php else: ?>
        <tr><td colspan="7">Nenhum agendamento cadastrado.</td></tr>
    <?php endif; ?>
    </tbody>
</table>
<?php rodape(); ?>
