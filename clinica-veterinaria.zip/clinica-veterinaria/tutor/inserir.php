<?php
$raiz = "../";
require __DIR__ . '/../auth.php';

$erro = '';
$v = ['nome' => '', 'cpf' => '', 'telefone' => '', 'email' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $v['nome']     = trim($_POST['nome'] ?? '');
    $v['cpf']      = trim($_POST['cpf'] ?? '');
    $v['telefone'] = trim($_POST['telefone'] ?? '');
    $v['email']    = trim($_POST['email'] ?? '');

    if ($v['nome'] === '') {
        $erro = "Informe o nome.";
    } elseif (!cpf_valido($v['cpf'])) {
        $erro = "CPF deve ter 11 dígitos.";
    } elseif ($v['email'] !== '' && !filter_var($v['email'], FILTER_VALIDATE_EMAIL)) {
        $erro = "E-mail inválido.";
    } else {
        $hash = cpf_hash($v['cpf']);
        $stmt = $conn->prepare("INSERT INTO tutores (nome, cpf_criptografado, telefone, email) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $v['nome'], $hash, $v['telefone'], $v['email']);
        $stmt->execute();
        header("Location: listar.php?ok=" . urlencode("Tutor cadastrado com sucesso."));
        exit;
    }
}

cabecalho("Novo Tutor", $raiz);
?>
<div class="card estreito">
    <h1>Cadastrar Tutor</h1>
    <?php if ($erro): ?><div class="alert erro"><?= e($erro) ?></div><?php endif; ?>
    <form method="post">
        <div class="input-group"><label>Nome completo</label>
            <input name="nome" value="<?= e($v['nome']) ?>" required></div>
        <div class="input-group"><label>CPF (será armazenado criptografado)</label>
            <input name="cpf" value="<?= e($v['cpf']) ?>" placeholder="000.000.000-00" maxlength="14" required></div>
        <div class="input-group"><label>Telefone</label>
            <input name="telefone" value="<?= e($v['telefone']) ?>" placeholder="(11) 90000-0000"></div>
        <div class="input-group"><label>E-mail</label>
            <input type="email" name="email" value="<?= e($v['email']) ?>"></div>
        <div class="btn-group">
            <a class="btn btn-cancel" href="listar.php">Cancelar</a>
            <button class="btn" type="submit">Salvar</button>
        </div>
    </form>
</div>
<?php rodape(); ?>
