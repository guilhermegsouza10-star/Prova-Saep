<?php
$raiz = "../";
require __DIR__ . '/../auth.php';

$busca = trim($_GET['busca'] ?? '');

if ($busca !== '') {
    $like = "%" . $busca . "%";
    // CPF é armazenado criptografado: compara o hash do termo digitado
    $hash = cpf_valido($busca) ? cpf_hash($busca) : '';
    $stmt = $conn->prepare(
        "SELECT * FROM tutores
         WHERE nome LIKE ? OR email LIKE ? OR telefone LIKE ? OR cpf_criptografado = ?
         ORDER BY nome"
    );
    $stmt->bind_param("ssss", $like, $like, $like, $hash);
    $stmt->execute();
    $resultado = $stmt->get_result();
} else {
    $resultado = $conn->query("SELECT * FROM tutores ORDER BY nome");
}

cabecalho("Tutores", $raiz);
?>
<div class="top">
    <h1>Tutores</h1>
    <a class="btn" href="inserir.php">+ Novo Tutor</a>
</div>

<?php mensagem(); ?>

<form class="busca" method="get" action="listar.php">
    <input type="text" name="busca" value="<?= e($busca) ?>" placeholder="Buscar por nome, e-mail, telefone ou CPF">
    <button type="submit" class="btn">Buscar</button>
    <?php if ($busca !== ''): ?>
        <a class="btn btn-cancel" href="listar.php">Limpar</a>
    <?php endif; ?>
</form>

<table>
    <thead>
        <tr><th>ID</th><th>Nome</th><th>CPF</th><th>Telefone</th><th>E-mail</th><th>Ações</th></tr>
    </thead>
    <tbody>
    <?php if ($resultado && $resultado->num_rows): ?>
        <?php while ($t = $resultado->fetch_assoc()): ?>
            <tr>
                <td><?= (int) $t['id'] ?></td>
                <td><?= e($t['nome']) ?></td>
                <td><span class="small">🔒 protegido</span></td>
                <td><?= e($t['telefone']) ?></td>
                <td><?= e($t['email']) ?></td>
                <td>
                    <a href="editar.php?id=<?= (int) $t['id'] ?>">Editar</a>
                    <a class="delete" href="apagar.php?id=<?= (int) $t['id'] ?>"
                       onclick="return confirm('Excluir este tutor? Pets e agendamentos dele também serão excluídos.')">Excluir</a>
                </td>
            </tr>
        <?php endwhile; ?>
    <?php else: ?>
        <tr><td colspan="6">Nenhum tutor encontrado.</td></tr>
    <?php endif; ?>
    </tbody>
</table>
<?php rodape(); ?>
