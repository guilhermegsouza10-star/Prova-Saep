<?php
$raiz = "../";
require __DIR__ . '/../auth.php';

$id = (int) ($_GET['id'] ?? 0);
$stmt = $conn->prepare("DELETE FROM tutores WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
header("Location: listar.php?ok=" . urlencode("Tutor excluído."));
exit;
