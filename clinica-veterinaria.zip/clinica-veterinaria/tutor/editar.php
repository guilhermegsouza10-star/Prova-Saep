<?php
$raiz = "../";
require __DIR__ . '/../auth.php';

$id = (int) ($_GET['id'] ?? 0);
$stmt = $conn->prepare("SELECT * FROM tutores WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$tutor = $stmt->get_result()->fetch_assoc();

if (!$tutor) {
    header("Location: listar.php?erro=" . urlencode("Tutor não encontrado."));
    exit;
}

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tutor['nome']     = trim($_POST['nome'] ?? '');
    $tutor['telefone'] = trim($_POST['telefone'] ?? '');
    $tutor['email']    = trim($_POST['email'] ?? '');
    $cpf               = trim($_POST['cpf'] ?? '');

    if ($tutor['nome'] === '') {
        $erro = "Informe o nome.";
    } elseif ($cpf !== '' && !cpf_valido($cpf)) {
        $erro = "CPF deve ter 11 dígitos.";
    } elseif ($tutor['email'] !== '' && !filter_var($tutor['email'], FILTER_VALIDATE_EMAIL)) {
        $erro = "E-mail inválido.";
    } else {
        if ($cpf !== '') {
            // novo CPF informado: grava criptografado
            $hash = cpf_hash($cpf);
            $stmt = $conn->prepare("UPDATE tutores SET nome = ?, cpf_criptografado = ?, telefone = ?, email = ? WHERE id = ?");
            $stmt->bind_param("ssssi", $tutor['nome'], $hash, $tutor['telefone'], $tutor['email'], $id);
        } else {
            // CPF em branco: mantém o atual
            $stmt = $conn->prepare("UPDATE tutores SET nome = ?, telefone = ?, email = ? WHERE id = ?");
            $stmt->bind_param("sssi", $tutor['nome'], $tutor['telefone'], $tutor['email'], $id);
        }
        $stmt->execute();
        header("Location: listar.php?ok=" . urlencode("Tutor atualizado com sucesso."));
        exit;
    }
}

cabecalho("Editar Tutor", $raiz);
?>
<div class="card estreito">
    <h1>Editar Tutor</h1>
    <?php if ($erro): ?><div class="alert erro"><?= e($erro) ?></div><?php endif; ?>
    <form method="post">
        <div class="input-group"><label>Nome completo</label>
            <input name="nome" value="<?= e($tutor['nome']) ?>" required></div>
        <div class="input-group"><label>CPF</label>
            <input name="cpf" placeholder="Deixe em branco para manter o CPF atual" maxlength="14"></div>
        <div class="input-group"><label>Telefone</label>
            <input name="telefone" value="<?= e($tutor['telefone']) ?>"></div>
        <div class="input-group"><label>E-mail</label>
            <input type="email" name="email" value="<?= e($tutor['email']) ?>"></div>
        <div class="btn-group">
            <a class="btn btn-cancel" href="listar.php">Cancelar</a>
            <button class="btn" type="submit">Atualizar</button>
        </div>
    </form>
</div>
<?php rodape(); ?>
