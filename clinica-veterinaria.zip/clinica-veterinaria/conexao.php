<?php
// Conexão com o banco (XAMPP / MariaDB)
// Ajuste $banco para o nome exato do banco que você importou o saep_db.sql.
$servidor = "127.0.0.1";
$usuario  = "root";
$senha    = "";
$banco    = "clínica_veterinaria";
$porta    = 3307; // padrão do XAMPP é 3306; seu dump foi gerado na 3307

mysqli_report(MYSQLI_REPORT_OFF);
$conn = @new mysqli($servidor, $usuario, $senha, $banco, $porta);

if ($conn->connect_errno) {
    die("Erro ao conectar no banco de dados: " . htmlspecialchars($conn->connect_error) .
        "<br>Verifique host, porta e nome do banco em conexao.php");
}
$conn->set_charset("utf8mb4");
