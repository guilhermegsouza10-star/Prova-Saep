<?php
date_default_timezone_set('America/Sao_Paulo');
session_start();
require_once __DIR__ . '/conexao.php';
require_once __DIR__ . '/funcoes.php';

// Já logado e sessão válida -> vai para a tela principal
if (!empty($_SESSION['usuario_id']) && isset($_SESSION['ultimo_acesso']) && (time() - $_SESSION['ultimo_acesso']) <= 600) {
    header("Location: index.php");
    exit;
}

$erro = $_GET['msg'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';

    if ($email === '' || $senha === '') {
        $erro = "Preencha e-mail e senha.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erro = "Informe um e-mail válido.";
    } else {
        $stmt = $conn->prepare("SELECT id, nome, email, senha FROM usuarios WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $usuario = $stmt->get_result()->fetch_assoc();

        if ($usuario && hash_equals($usuario['senha'], senha_hash($senha))) {
            session_regenerate_id(true);
            $_SESSION['usuario_id']    = $usuario['id'];
            $_SESSION['nome']          = $usuario['nome'];
            $_SESSION['email']         = $usuario['email'];
            $_SESSION['ultimo_acesso'] = time();
            header("Location: index.php");
            exit;
        }
        // Falha na autenticação (mensagem genérica de propósito)
        $erro = "E-mail ou senha incorretos.";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Clínica Veterinária</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body class="login-page">
    <div class="login-card">
        <h2>🐾 Clínica Veterinária</h2>
        <?php if ($erro): ?>
            <div class="alert erro"><?= e($erro) ?></div>
        <?php endif; ?>
        <form method="post" action="login.php">
            <div class="input-group">
                <label for="email">E-mail</label>
                <input type="email" id="email" name="email" placeholder="seu@email.com" value="<?= e($_POST['email'] ?? '') ?>" required>
            </div>
            <div class="input-group">
                <label for="senha">Senha</label>
                <input type="password" id="senha" name="senha" placeholder="Sua senha" required>
            </div>
            <button type="submit" class="btn">Entrar</button>
        </form>
    </div>
</body>
</html>
